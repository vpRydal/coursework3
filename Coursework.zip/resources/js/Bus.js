import Vue from 'vue'

export const bus = new Vue();
