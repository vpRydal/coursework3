import Vue from 'vue'

require('./bootstrap');

Vue.components('Header', require('./Components/Header'));
