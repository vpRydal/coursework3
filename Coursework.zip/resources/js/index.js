import Vue from "vue";
import router from './router'
import store from './Store/index'

require('./bootstrap');

Vue.component('Header', () => import('./Components/Header'));
Vue.component('Layout', () => import('./Components/Layout'));

const header = new Vue({
    el: '#header',
    render: h => h(Vue.component('Header')),
    router,
    store,

});
const content = new Vue({
    el: '#index',
    render: h => h(Vue.component('Layout')),
    router,
    store,
});
