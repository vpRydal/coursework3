<template>
    <div class="container d-flex flex-column flex-lg-row my-5">
        <aside id="catalog" class="float-left" style="min-width: 250px">
            <div class="p-md-2">
                <ul class="list-group list-group-flush">
                    <li v-for="(category, index) of categories" category="" class="list-group-item">
                        <div class="">
                            <a class="text-muted text-decoration-none" data-toggle="collapse"
                               :href="`#collapseExample${index}`" role="button"
                               aria-expanded="false" aria-controls="collapseExample">
                                {{ category.name }}
                            </a>
                            <div class="collapse" :id="`collapseExample${index}`">
                                <ul>
                                    <li v-for="childCategory of category.child_categories"
                                        class="list-group-item card card-body">
                                        <a class="text-muted text-decoration-none" role="button"
                                           @click="selectProductsByCategory(childCategory.id)">
                                            {{ childCategory.name }}
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </li>
                </ul>
            </div>
        </aside>
        <main id="products" class="">
            <div class="my-2 d-flex flex-wrap float-left">
                <div v-for="product of productsByCategory" class="my-1 mx-auto mx-lg-2">
                    <Product
                        :title="product.title"
                        :cost="product.cost"
                        :short-description="product.short_description"
                        :img-path="product.img_path"
                        :slug="product.slug"
                    ></Product>
                </div>
            </div>
        </main>
    </div>
</template>

<script>
    import Product from './Product'

    export default {
        name: "Catalog",
        components: {
            Product: Product
        },
        data() {
            return {
                categories: [],
                productsByCategory: []
            }
        },
        async created() {
            axios.get(`/api/products/popular`)
                .then(response => response.data.products)
                .then(products => {
                    this.productsByCategory = products
                });
            axios.get(`/api/categories`)
                .then(response => response.data.categories)
                .then(categories => {
                    this.categories = categories
                });
        },
        methods: {
            async selectProductsByCategory(categoryId) {
                this.productsByCategory = (await axios.get(`/api/category/${categoryId}/products`)).data.products
            }
        },
    }
</script>

<style scoped>

</style>
