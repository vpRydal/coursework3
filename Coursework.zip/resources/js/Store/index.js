import Vuex from 'vuex'
import Vue from "vue";
import Auth from "./modules/Auth/Index";
import Cart from "./modules/Cart/Index";

Vue.use(Vuex);

let store = new Vuex.Store({
    modules: {
        auth: Auth,
        cart: Cart,

    }
});

export default store;
